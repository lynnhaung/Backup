
//alert($(".forumng-replylink > a").length);
//$(".forumng-replylink > a").click();

$(".forumng-post-outerbox:first").each(function (_i, _post) {
	_post = $(_post);
	var _a = _post.find(".forumng-replylink > a");
	var _url = _a.attr("href");
	//editpost.php?replyto=20
	var _replyto = _url.substr(_url.lastIndexOf("replyto=")+8);
	//alert(_replyto);
	// 20
	_post.append('<iframe class="forumng-inlineform" height="627" src="editpost.php?replyto=' + _replyto + '&iframe=1&mode=discuss" width="100%"></iframe>');
});


$(function () {
	
	$(".forumng-expandtext").click();
	$("#id_submitbutton").val("儲存");

});








